# Technical-Khawar-
CAMMANDS
$pkg update
$pkg upgrade
$pkg install python
$pkg install python2
$pkg install git -y
$pip2 install requests
$pip2 install mechanize
$git clone https://github.com/Khawar7346/Technical-Khawar-.git
$cd khawar7346
$chmod +x khawar7346
$python2 khawar7346.py
